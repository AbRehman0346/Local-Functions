class Pyramid2{
	public static void DownPyramid(){
		int M,Sp,N,NL=13,SpL=0;
		for(M=14; M>=1; M--)
		{
			
			for(Sp=1; Sp<=SpL; Sp++)
			{
				System.out.print(" ");
			}
			
			
			for(N=NL; N>=1; N--)
			{
				System.out.print("*");
			}
			NL -= 2;
			SpL++;
			System.out.println();
			
		}
	}

	public static void main(String arug[]){
		int i,space,k,a=6,b=1;
		for(i=1; i<=7; i++)
		{
			for(space=1; space<=a; space++)
			{
				System.out.print(" ");
			}
			
			for(k=1; k<=b; k++)
			{
				System.out.print("*");
			}
			a--;
			b += 2;
			System.out.println();
		}
		DownPyramid();
	}
}