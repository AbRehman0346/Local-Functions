import java.util.Scanner;
class Power{
	static char z;
	public static void main(String arug[]){
		Scanner input = new Scanner(System.in);
	do{
		int E, B, i, result=1;
		System.out.print("Enter Base= ");
		B = input.nextInt();
		System.out.print("Enter Exponent= ");
		E = input.nextInt();
		for(i=1; i<=E; i++)
		{
			result = result * B;	
		}
		System.out.println(E + "^" + B + " = " + result);
		System.out.println("Enter Y to continue otherwise any character to Finish.");
		System.out.print("=>");
		z = input.next().charAt(0);	
	}
	while(z == 'y' || z == 'Y');
	}
}