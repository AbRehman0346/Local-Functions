class Game{
	public static void main(String arug[]){
		
		for(int i=1; i<=9; i++)
		{
				
			if (i == 3 || i == 6)
			{
				for (int j=1; j<=25; j++)
				{
					System.out.print("#");
				}	
			}
			if (i == 3 || i == 6)
			{
				continue;
			}
			System.out.println("\t" + "#" + "\t" + "#");
		}
	

	}

}