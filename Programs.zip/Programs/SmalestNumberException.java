class SmalestNumber{
	public static void main(String arug[]){
		int check = 0;
		int Numbers[] = {1,2,3,4,5,6,7,8};
		for(int i:Numbers)
		{
			
			if(check < Numbers[i])
			{
				check = Numbers[i];
			}
		}
		System.out.println("Smalest Number is " + check);
	}
}