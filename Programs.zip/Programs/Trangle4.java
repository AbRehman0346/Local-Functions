class Trangle4{
	public static void main(String arug[]){
		int i,k,j,a=0;
		for(i=5; i>=1; i--)
		{
			if(i != 5)
			{
				for(j=1; j<=a; j++)
				{
					System.out.print(" ");
				}
			}
			
			for(k=1; k<=i; k++)
			{
				System.out.print("*");
			}
			a++;
			System.out.println();
		}
	}
}