import java.util.Scanner;
class MatrixAddition{
	public static void main(String arug[]){
		Scanner input = new Scanner(System.in);
		int Matrix1[][] = new int[2][2];
//Getting Input for Matrix1.
		System.out.println("Enter the Number for Matrix one");			
		for(int i=0; i<=1; i++)
		{			
			for(int j=0; j<=1; j++)
			{				
				Matrix1[i][j] = input.nextInt();
			}				
		}				
						
//Getting Input for Matrix2.	
		System.out.println("Enter the Numbers for Matrix 2");					
		int Matrix2[][] = new int[2][2];
		for(int i=0; i<=1; i++)
		{				
			for(int j=0; j<=1; j++)
			{			
				Matrix2[i][j] = input.nextInt();
			}			
		}				
							
//Loops For Addition Of Matrix.				
		int Result[][] = new int[2][2];
		for(int i=0; i<=1; i++)
		{						
			for(int j=0; j<=1; j++)			
			{					
				Result[i][j] = Matrix1[i][j] + Matrix2[i][j];
			}				
		}				
						
//Loops For Printing the Results..
		int count = 0;
		System.out.println("Results are ");				
		for(int i=0; i<=1; i++)
		{					
			for(int j=0; j<=1; j++)
			{			
				count = count + 1;
				System.out.print(Result[i][j] + " ");
				if(count == 2)					
				{				
					System.out.print("\n");
				}			
				
			}
		}
	}
}