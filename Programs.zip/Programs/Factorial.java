import java.util.Scanner;
class Factorial{
	public static void main(String arug[]){
		Scanner input = new Scanner(System.in);
		int fect, result=1, i;
		System.out.println("Enter Number to calculate its Factorial");
		System.out.print("=>");
		fect = input.nextInt();
		for(i=fect; i>=1; i--)
		{
			result = result * i;
		}
		System.out.println("Factorial of "+ fect + " is " + result);
}
}