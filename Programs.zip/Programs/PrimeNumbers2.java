import java.util.Scanner;
class PN1by1{
	static char z;
	public static void main(String arug[]){
		do
		{
			Scanner input = new Scanner(System.in);
			int p,i,j,count=0;
			if(z != 'y' && z != 'Y')
			{
				System.out.println("This Program tells that weather number is prime or not.");
			}
			System.out.print("Enter Number ");
			p=input.nextInt();
			for(i=1; i<=p; i++)
			{
				if(p % i == 0)
				{
					count = count + 1;
				}
			}
			if(count <= 2)
			{
				System.out.println(p + " is a Prime Number.");
			}
			else
			{
				System.out.println(p + " is not a Prime Number.");
			}
			System.out.println("To try another number press y otherwise any character to finish.");
			System.out.print("=> ");
			z = input.next().charAt(0);
		}
		while(z == 'Y' || z == 'y');		
	}
}