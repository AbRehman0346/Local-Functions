import java.util.Scanner;
class MultiAdd{
	public static void main(String arug[]){
		Scanner input = new Scanner(System.in);
		int num, i, result=0;
		System.out.println("Enter Number to Multiply it 10 Times");
		System.out.print("=> ");
		num = input.nextInt();
		for(i=1; i<=10; i++)
		{
			result = num + result;
		}
		System.out.println("Ten Time Multiplication is " + result);
	}
}