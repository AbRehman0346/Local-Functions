import java.util.Scanner;
import java.io.IOException;
class TicCross{
	static int choice = 0;
	static char turn = 'x';
	
	static char board[][] = {{'1','2','3'},{'4','5','6'},{'7','8','9'}};
									
	public static void cls(){
		try
		{		
			new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
		}catch(Exception E)
		{		
			System.out.println(E);
		}				
	}
					
//Checking if the Board Box is Already Filled or Not
	public static void CheckIfFilled(){
		Scanner input = new Scanner(System.in);
		choice = 0;
		System.out.print("Enter Number ");	
		choice = input.nextInt();
								
		if ((choice == 1) && (board[0][0] == 'x' || board[0][0] == '0'))
		{			
			System.out.println("Block 1 is already filled");
			CheckIfFilled();
		}		
		else if ((choice == 2) && (board[0][1] == 'x' || board[0][1] == '0'))
		{					
			System.out.println("Block 2 is already filled");
			CheckIfFilled();
		}				
		else if ((choice == 3) && (board[0][2] == 'x' || board[0][2] == '0'))
		{			
			System.out.println("Block 3 is already filled");		
			CheckIfFilled();
		}					
		else if ((choice == 4) && (board[1][0] == 'x' || board[1][0] == '0'))
		{			
			System.out.println("Block 4 is already filled");
			CheckIfFilled();
		}			
		else if ((choice == 5) && (board[1][1] == 'x' || board[1][1] == '0'))
		{				
			System.out.println("Block 5 is already filled");
			CheckIfFilled();
		}				
		else if ((choice == 6) && (board[1][2] == 'x' || board[1][2] == '0'))
		{			
			System.out.println("Block 6 is already filled");
			CheckIfFilled();
		}			
		else if ((choice == 7) && (board[2][0] == 'x' || board[2][0] == '0'))
		{
			System.out.println("Block 7 is already filled");
			CheckIfFilled();
		}
		else if ((choice == 8) && (board[2][1] == 'x' || board[2][1] == '0'))
		{
			System.out.println("Block 8 is already filled");
			CheckIfFilled();
		}
		else if ((choice == 9) && (board[2][2] == 'x' || board[2][2] == '0'))
		{
			System.out.println("Block 9 is already filled");
			CheckIfFilled();
		}
		Playing();
					
}				
									
	public static void MakingBoard(){
		cls();
		System.out.println("\tTIC TOC TOE GAME");
		System.out.println("\n\tPlayer 1 --> x");
		System.out.println("\tPlayer 2 --> 0");
		System.out.println("\n");
		System.out.println("\t\t     |     |     ");
		System.out.println("\t\t "+ board[0][0] +"   |  "+ board[0][1] +"  |   "+board[0][2]+"  ");
		System.out.println("\t\t_____|_____|_____");
		System.out.println("\t\t     |     |     ");
		System.out.println("\t\t "+ board[1][0]+"   |  "+ board[1][1]+"  |  "+ board[1][2]+"  ");
		System.out.println("\t\t_____|_____|_____");
		System.out.println("\t\t     |     |     ");
		System.out.println("\t\t "+ board[2][0]+"   |  "+ board[2][1]+"  |  "+ board[2][2]+"  ");
		System.out.println("\t\t     |     |     ");
	}			
		
	public static void Turn(){
		
		MakingBoard();
							
		if(turn == 'x')
		{
			System.out.print("\tPlayer 1 ");
			turn = '0';
		}
		else if (turn == '0')
		{
			System.out.print("\tPlayer 2 ");
			turn = 'x';
		}
}						
					
	public static void Playing(){ 
						
		switch(choice)
		{
			case 1:
			{
				if(turn == '0')
				{
					board[0][0] = 'x';
				}
				if(turn == 'x')
				{
					board[0][0] = '0';
				}
				break;
				
			}
			case 2:
			{
				if(turn == '0')
				{
					board[0][1] = 'x';
				}
				if(turn == 'x')
				{
					board[0][1] = '0';
				}
				break;
			}
			case 3:
			{
				if(turn == '0')
				{
					board[0][2] = 'x';
				}
				if(turn == 'x')
				{
					board[0][2] = '0';
				}
				break;
			}
			case 4:
			{
				if(turn == '0')
				{
					board[1][0] = 'x';
				}
				if(turn == 'x')
				{
					board[1][0] = '0';
				}
				break;
			}
			case 5:
			{
				if(turn == '0')
				{
					board[1][1] = 'x';
				}
				if(turn == 'x')
				{
					board[1][1] = '0';
				}
				break;	
			}
			case 6:
			{
				if(turn == '0')
				{
					board[1][2] = 'x';
				}
				if(turn == 'x')
				{
					board[1][2] = '0';
				}
				break;
			}
			case 7:	
			{
				if(turn == '0')
				{
					board[2][0] = 'x';
				}
				if(turn == 'x')
				{
					board[2][0] = '0';
				}
				break;
			}
			case 8:
			{
				if(turn == '0')
				{
					board[2][1] = 'x';
				}
				if(turn == 'x')
				{
					board[2][1] = '0';
				}
				break;
			}
			case 9:
			{
				if(turn == '0')
				{
					board[2][2] = 'x';
				}
				if(turn == 'x')
				{
					board[2][2] = '0';
				}
				break;	
			} 
			default:
				{
					System.out.println("Sorry!! Wrong Input");
					break;
				}
		}
		MakingBoard();			
								
	}

	static String gameover; 				
												
	public static boolean GameOver(){			
//Check If Game is Playings
		boolean checkboolean = true;
		for(int row=0; row<=2; row++)
		{				
			for(int column=0; column<=2; column++)	
			{			
				if(board[row][column] != 'x' && board[row][column] != '0')
				{				
					checkboolean = true;
				}
				
				
			}
		}				
							
//When Game Draw.					
		int count = 0;
		for(int row=0; row<=2; row++)
		{						
			for(int column=0; column<=2; column++)
				{				
					if(board[row][column] == 'x' || board[row][column] == '0')
					{				
						count = count + 1;					
						if(count == 9)
						{			
							checkboolean = false;
							gameover = "GameDraw";
						}
													
					}				
									
				}				
		}
														
//Game Winning					
		for(int i=0; i<=2; i++)
		{				
			if(board[i][0] == board[i][1] && board[i][0] == board[i][2])
			{						
				checkboolean = false;
			}
			else if(board[0][i] == board[1][i] && board[0][i] == board[2][i])
				checkboolean = false;					
		}
		if(board[0][0] == board[1][1] && board[0][0] == board[2][2])
			checkboolean = false;
		else if(board[0][2] == board[1][1] && board[0][2] == board[2][0])
			checkboolean = false;					
		return checkboolean;				
}																								
							
	public static void main(String arug[]){
		while(GameOver())
		{			
			Turn();
			CheckIfFilled();
			GameOver();
//Just for ending the loop.		
			if(choice == 0)
			{		
				break;
			}	
		}
		if(gameover == "GameDraw")
		{				
			System.out.println("\n\tGame Draw");
		}					
		else if(turn == '0')
		{
			System.out.println("\n\tPlayer 1 Wins");
		}
		else if(turn == 'x')
		{
			System.out.println("\n\tPlayer 2 Wins");
		}
					
	}	
}