import java.util.Scanner;
class Table{
	static char z;
	public static void main(String arug[]){
		Scanner input = new Scanner(System.in);
		do
		{
			int t,i,r;
			System.out.println("Enter number to print it's Table");
			System.out.print("=> ");
			t = input.nextInt();
			System.out.println("Enter range of Table");
			System.out.print("=> ");
			r = input.nextInt();
			for(i=1; i<=r; i++)
			{
				System.out.println( t + "*" + i + "= " + t*i );
			}
			System.out.println("To try another number press y otherwise any character to finish");
			System.out.print("=> ");
			z = input.next().charAt(0);
		}
		while(z == 'Y' || z == 'y');
		
	}
}