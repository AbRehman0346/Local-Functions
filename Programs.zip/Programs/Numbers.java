class Numbers{
	public static void main(String arug[]){
		int i,j,r=5;
		for(i=1; i<=5; i++)
		{
			for(j=i; j<=r; j++)
			{
				System.out.print(j);
			}
			r++;
			System.out.println();
		}
	}
}