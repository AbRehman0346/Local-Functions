class Trangle3{
	public static void main(String arug[]){
		int i,j,k,a=4;
		for(i=1; i<=5; i++)
		{
			for(j=1; j<=a; j++)
			{
				System.out.print(" ");
			}
			
			for(k=1; k<=i; k++)
			{
				System.out.print("*");
			}
			a--;
			System.out.println();
		}
	}
}