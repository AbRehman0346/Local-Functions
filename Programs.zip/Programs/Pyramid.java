class Pyramid{
	public static void main(String arug[]){
		int i,space,k,a=6,b=1;
		for(i=1; i<=7; i++)
		{
			for(space=1; space<=a; space++)
			{
				System.out.print(" ");
			}
			
			for(k=1; k<=b; k++)
			{
				System.out.print("*");
			}
			a--;
			b += 2;
			System.out.println();
		}
	}
}