import java.util.Scanner;
class ATM{
	static int Amount;
	static char i; 
	public static void main(String arug[]){
		do
		{
			int FiveThousand=0, Thousand=0, FiveHundered=0, Hundered=0, Fifty=0,Twenty=0,Ten=0;
			Scanner Input = new Scanner(System.in);
			System.out.print("Enter Amount to Withdraw Money= ");
			Amount = Input.nextInt();
			if (Amount >= 5000)
			{
				while(Amount >= 5000)
				{
					FiveThousand=FiveThousand+1;
					Amount-=5000;
				}
				System.out.println("5000" + "----->" + FiveThousand);
			}
			if (Amount >= 1000)
			{
				while(Amount >= 1000)
				{
					Thousand=Thousand+1;
					Amount-=1000;
				}
				System.out.println("1000" + "----->" + Thousand);
			}
			if (Amount >= 500)
			{
				while(Amount >= 500)
				{
					FiveHundered=FiveHundered+1;
					Amount-=500;
				}
				System.out.println("500" + "----->" + FiveHundered);
			}
			if (Amount >= 100)
			{
				while(Amount >= 100)
			{
				Hundered=Hundered+1;
				Amount-=100;
			}
			System.out.println("100" + "----->" + Hundered);
			}
			if (Amount >= 50)
			{
				while(Amount >= 50)
				{
					Fifty=Fifty+1;
					Amount-=50;
				}
				System.out.println("50" + "----->" + Fifty);
			}
			if (Amount >= 20)
			{
				while(Amount >= 20)
				{
					Twenty=Twenty+1;
					Amount-=20;
				}
				System.out.println("20" + "----->" + Twenty);
			}
			if (Amount >= 10)
			{
				while(Amount >= 10)
				{
					Ten=Ten+1;
					Amount-=10;
				}
				System.out.println("10" + "----->" + Ten);
			}
			System.out.println("Remaining" + "----->" + Amount);
		System.out.println("If you want to check an other number then press y otherwise any character to exit");
		System.out.print("=>");
		i = Input.next().charAt(0);
	}
	while(i == 'Y' || i == 'y');
			 
	}
}