class MarkSheet{
	public static void main(String arug[]){
		int CAPS=90, OOP=95, AppliedPhysics=94, Calculus=80, DiscreteStructure=85;
		System.out.println("\t\t\tBoard of Intermediate and Secondary Education Sukkur, Sindh");
		System.out.println("\t\t\t\t\t\tMark Sheet \t\t\t\t\t\tGroup: AD-2");
		System.out.println();
		System.out.println("\tName: Abdul Rehman \t\t\t\t\t\t Father's Name: Muneer Ahmed");		
		System.out.println("\tSurName: Lashari \t\t\t\t\t\t M.O.Identification: MOLE ON THE LEFT CHEEK");
		System.out.println("\tInstitute: IBA Community College Naushahro Feroze");
		System.out.println();
		System.out.println("\tSubjects \t\t Mix Marks \t\t Min Marks \t\t Obt. Marks \t\t Grade");
		System.out.println("\tCAPS \t\t\t   100 \t\t\t    60 \t\t\t     " + CAPS + "\t\t\t  A1");
		System.out.println("\tOOP  \t\t\t   100 \t\t\t    60 \t\t\t     " + OOP  + "\t\t\t  A1");
		System.out.println("\tApplied Physics \t   100 \t\t\t    60 \t\t\t     " + CAPS + "\t\t\t  A1");
		System.out.println("\tCalculus \t\t   100 \t\t\t    60 \t\t\t     " + Calculus + "\t\t\t  A");
		System.out.println("\tDiscrete Structure \t   100 \t\t\t    60 \t\t\t     " + DiscreteStructure + "\t\t\t  B");
		System.out.println("\tTotal \t\t\t   500 \t\t\t    -   \t\t     " + (CAPS+OOP+AppliedPhysics+Calculus+DiscreteStructure) + "\t\t  A1");
		System.out.println();
		System.out.println("\tResult: Pass");
		System.out.println("\tGrade: A1");
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println("\t\t\t\t\t\t\t\t\t\t\tController of Examinatins");
	}
}